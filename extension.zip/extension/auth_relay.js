// Listen for messages from the web app
window.addEventListener("message", (event) => {
    // We only accept messages from ourselves
    if (event.source !== window) return;

    if (event.data.type && (event.data.type === "MEMWYRE_AUTH_SUCCESS")) {
        console.log("Memwyre Extension: Received auth token from web app");

        // Relay to background script
        chrome.runtime.sendMessage({
            action: "saveToken",
            token: event.data.token,
            refreshToken: event.data.refreshToken,
            user: event.data.user
        });
    }

    if (event.data.type && (event.data.type === "MEMWYRE_AUTH_LOGOUT")) {
        console.log("Memwyre Extension: Logout received from web app");
        chrome.runtime.sendMessage({ action: "logout" });
    }
});

// Announce readiness — solves the OAuth race condition where the web app
// broadcasts tokens before this content script has loaded
window.postMessage({ type: "MEMWYRE_RELAY_READY" }, "*");
