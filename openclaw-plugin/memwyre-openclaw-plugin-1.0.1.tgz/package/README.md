# OpenClaw MemWyre Plugin

This plugin enables the OpenClaw autonomous agent to seamlessly use MemWyre as its persistent memory and context engine. It provides the agent with first-class tools to save notes and retrieve context from the MemWyre Vault.

## Installation

Assuming you have OpenClaw installed, you can link or copy this directory into your OpenClaw plugins directory, or install it via the OpenClaw CLI using the local path.

1. Ensure dependencies are installed in this plugin folder:
   ```bash
   cd openclaw-plugin
   npm install
   ```

2. Register the plugin with OpenClaw:
   ```bash
   openclaw plugins install /path/to/openclaw-plugin
   ```

## Configuration

You must configure the plugin in your OpenClaw settings (usually `~/.openclaw/config.json` or via OpenClaw's plugin management CLI) with your MemWyre API key.

```json
{
  "plugins": {
    "@memwyre/openclaw-plugin": {
      "apiKey": "bv_sk_your_api_key_here",
      "hostUrl": "http://localhost:8000"
    }
  }
}
```

- **`apiKey`**: Generate this from the MemWyre web interface under Settings > API Keys.
- **`hostUrl`**: The URL where your MemWyre backend is running. If deploying to production, change this to your live URL (e.g., `https://api.yourdomain.com`).

## Tools Provided

Once configured, the OpenClaw agent will have access to the following tools:
- **`save_memory(text, tags)`**: Saves a new memory/note directly into your MemWyre Inbox.
- **`search_memwyre(query)`**: Performs semantic search across your MemWyre Vault to retrieve past context.
